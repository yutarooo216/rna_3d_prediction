import boto3
import os
from urllib.parse import unquote_plus

s3 = boto3.client('s3')
ses = boto3.client('ses')

def lambda_handler(event, context):
    record = event['Records'][0]
    bucket = record['s3']['bucket']['name']
    key = unquote_plus(record['s3']['object']['key'])

    # UUID 抽出（例：output/<uuid>/<uuid>.zip）
    uuid = key.split('/')[1]

    # メールアドレスは json ファイルから取得すると仮定
    json_key = f"output/{uuid}/{uuid}.json"
    response = s3.get_object(Bucket=bucket, Key=json_key)
    email = list(eval(response['Body'].read().decode('utf-8')).values())[0]

    # .zipへの署名付きURL
    url = s3.generate_presigned_url(
        ClientMethod='get_object',
        Params={'Bucket': bucket, 'Key': key},
        ExpiresIn=3600
    )

    # domain
    domain = os.environ.get('DOMAIN')

    ses.send_email(
        Source=f"no-reply@{domain}",
        Destination={"ToAddresses": [email]},
        Message={
            "Subject": {"Data": "Your RNA prediction is ready"},
            "Body": {
                "Text": {
                    "Data": f"Here is your result:\n{url}"
                }
            }
        }
    )